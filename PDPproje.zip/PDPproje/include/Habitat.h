#ifndef HABITAT_H
#define HABITAT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Bitki.h>
#include <Bocek.h>
#include <Sinek.h>
#include <Pire.h>
#include <Canli.h>
#include "Node.h"

struct HABITAT {
    int sutun_sayisi;
    
    void (*yokEt)(struct HABITAT*);
    void (*goster)(struct HABITAT*, struct Node*);
    struct Node* (*guncelle)(struct HABITAT*, struct Node*);
};
struct HABITAT* habitatOlustur(int);

void print(struct HABITAT*, struct Node*);

struct Node* update(struct HABITAT*, struct Node*);

void habitatYokEt(struct HABITAT*);

#endif