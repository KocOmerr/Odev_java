#ifndef NODE_H
#define NODE_H

#include "Bitki.h"
#include "Bocek.h"
#include "Pire.h"
#include "Sinek.h"

struct Node
{
    int konum;
    struct BITKI* bitki;
    struct BOCEK* bocek;
    struct SINEK* sinek;
    struct PIRE* pire;

    struct Node* next;
};

int listLength(struct Node*);

struct Node* newNode(struct BITKI*, struct BOCEK*, struct SINEK*, struct PIRE*, int);

struct Node* ekle(struct Node*,struct Node*);

struct Node* deleteNode(struct Node*);

void yokEt(struct Node*);

void printList(struct Node*,int);

#endif