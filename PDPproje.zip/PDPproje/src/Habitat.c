#include "Habitat.h"


struct HABITAT* habitatOlustur(int sutun)
{
    struct HABITAT* this;
    this = (struct HABITAT*)malloc(sizeof(struct HABITAT));
    this->sutun_sayisi = sutun;

    this->goster = &print;
    this->guncelle = &update;
    this->yokEt = &habitatYokEt;
}

void habitatYokEt(struct HABITAT* this)
{
    if(this == NULL) return;
    free(this);
}

void print(struct HABITAT* habitat, struct Node* head)
{
    struct Node* tmp = head;
    int sayac = 0;
    while(tmp != NULL)
    {
        if(tmp->bitki != NULL)
            printf("%c ",tmp->bitki->super->sembol);
        else if(tmp->bocek != NULL)
            printf("%c ",tmp->bocek->super->sembol);
        else if(tmp->sinek != NULL)
            printf("%c ",tmp->sinek->super->super->sembol);
        else if(tmp->pire != NULL)
            printf("%c ",tmp->pire->super->super->sembol);
        else
            printf("X ");
    
        if(sayac % habitat->sutun_sayisi == 0 && sayac != 0)
        {
            printf("\n");
        }
        sayac++;
        tmp = tmp->next;
    }
}

struct Node* update(struct HABITAT* habitat, struct Node* head)
{
    struct Node* canli1 = NULL;
    struct Node* canli2 = NULL;
    struct Node* tmp = head;
    int sayac = 0;
    int konum1 = 0;
    int konum2 = 0;
    int i = 0;

    while(tmp != NULL)
    {
        if((tmp->bocek != NULL || tmp->bitki != NULL || tmp->sinek != NULL || tmp->pire != NULL) && sayac == 0)
        {
            canli1 = tmp;
            konum1 = i;
            sayac ++;
        }
        else if((tmp->bocek != NULL || tmp->bitki != NULL || tmp->sinek != NULL || tmp->pire != NULL) && sayac == 1 )
        {
            canli2 = tmp;
            konum2 = i;
            break;
        }
        i ++;
        tmp = tmp->next;
    }

    if(canli2 == NULL)
    {
        if(canli1->bitki != NULL)
            printf("\nKAZANAN: %c (%d,%d)\n",canli1->bitki->super->sembol, konum1 / habitat->sutun_sayisi , konum1 % habitat->sutun_sayisi);
        else if(canli1->bocek != NULL)
            printf("\nKAZANAN: %c (%d,%d)\n",canli1->bocek->super->sembol, konum1 / habitat->sutun_sayisi , konum1 % habitat->sutun_sayisi);
        else if(canli1->sinek != NULL)
            printf("\nKAZANAN: %c (%d,%d)\n",canli1->sinek->super->super->sembol, konum1 / habitat->sutun_sayisi, konum1 % habitat->sutun_sayisi);
        else if(canli1->pire != NULL)
            printf("\nKAZANAN: %c (%d,%d)\n",canli1->pire->super->super->sembol, konum1/ habitat->sutun_sayisi , konum1 % habitat->sutun_sayisi);
        return head; 
    }

    //printf("\nCanli 1:(%d,%d)\n",konum1 / habitat->sutun_sayisi , konum1 % habitat->sutun_sayisi);
    //printf("Canli 2:(%d,%d)\n",konum2 / habitat->sutun_sayisi , konum2 % habitat->sutun_sayisi);

    if(canli1->pire != NULL)
    {
        if(canli2->pire != NULL)
        {
            if(canli1->pire->super->super->deger >= canli2->pire->super->super->deger)
            {
                canli2->pire->yoket(canli2->pire);
                canli2->pire = NULL;
            }
            else
            {
                canli1->pire->yoket(canli1->pire);
                canli1->pire = NULL;
            }
        }
        else
        {
            canli1->pire->yoket(canli1->pire);
            canli1->pire = NULL;
        }
    }
    else if(canli1->sinek != NULL)
    {
        if(canli2->sinek != NULL)
        {
            if(canli1->sinek->super->super->deger >= canli2->sinek->super->super->deger)
            {
                canli2->sinek->yoket(canli2->sinek);
                canli2->sinek = NULL;
            }
            else
            {
                canli1->sinek->yoket(canli1->sinek);
                canli1->sinek = NULL;
            }
        }
        else if (canli2->bocek != NULL)
        {
            canli2->bocek->yoket(canli2->bocek);
            canli2->bocek = NULL;
        }
        else if(canli2->pire != NULL)
        {
            canli2->pire->yoket(canli2->pire);
            canli2->pire = NULL;
        }
        else if(canli2->bitki != NULL)
        {
            canli1->sinek->yoket(canli1->sinek);
            canli1->sinek = NULL;
        }
    }
    else if(canli1->bitki != NULL)
    {
        if(canli2->bitki != NULL)
        {
            if(canli1->bitki->super->deger >= canli2->bitki->super->deger)
            {
                canli2->bitki->yoket(canli2->bitki);
                canli2->bitki = NULL;
            }
            else
            {
                canli1->bitki->yoket(canli1->bitki);
                canli1->bitki = NULL;
            }
        }
        else if(canli2->sinek != NULL)
        {
            canli2->sinek->yoket(canli2->sinek);
            canli2->sinek = NULL;
        }
        else if(canli2->pire != NULL)
        {
            canli2->pire->yoket(canli2->pire);
            canli2->pire = NULL;
        }
        else if(canli2->bocek != NULL)
        {
            canli1->bitki->yoket(canli1->bitki);
            canli1->bitki = NULL;
        }
    }
    else if(canli1->bocek != NULL)
    {
        if(canli2->bocek != NULL)
        {
            if(canli1->bocek->super->deger >= canli2->bocek->super->deger)
            {                        
                canli2->bocek->yoket(canli2->bocek);
                canli2->bocek = NULL;
            }
            else
            {
                canli1->bocek->yoket(canli1->bocek);
                canli1->bocek = NULL;
            }
        }
        else if(canli2->bitki != NULL)
        {
            canli2->bitki->yoket(canli2->bitki);
            canli2->bitki = NULL;
        }
        else if(canli2->pire != NULL)
        {
            canli2->pire->yoket(canli2->pire);
            canli2->pire = NULL;
        }
        else if(canli2->sinek != NULL)
        {
            canli1->bocek->yoket(canli1->bocek);
            canli1->bocek = NULL;
        }
    }

    return head;
}