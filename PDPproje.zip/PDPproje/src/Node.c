#include "Node.h"

struct Node* newNode(struct BITKI* bitki, struct BOCEK* bocek, struct SINEK* sinek, struct PIRE* pire, int konum)
{
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));
    node->bitki = bitki;
    node->bocek = bocek;
    node->pire = pire;
    node->sinek = sinek;
    node->konum = konum;
    node->next = NULL;

    return node;
}

void yokEt(struct Node* sil)
{
    if(sil == NULL) return;

    if(sil->bitki != NULL)
        sil->bitki->yoket(sil->bitki);
    else if(sil->bocek != NULL)
        sil->bocek->yoket(sil->bocek);
    else if(sil->sinek != NULL)
        sil->sinek->yoket(sil->sinek);
    else if(sil->pire != NULL)
        sil->pire->yoket(sil->pire);

    free(sil);
}

int listLength(struct Node* head)
{
    struct Node* tmp = head;
    int lenght = 1;

    if(head == NULL)
    {
        return 0;
    }
    while(tmp->next != NULL)
    {
        tmp = tmp->next;
        lenght ++;
    }

    return lenght;
}

void printList(struct Node* head, int Col)
{
    struct Node* tmp = head;
    int index = 0;
    while(tmp != NULL)
    {
        if(index % Col == 0)
        {
            printf("\n");
        }
        if(tmp->bitki != NULL)
        {
            printf("B ");
        }
        else if(tmp->bocek != NULL)
        {
            printf("C ");
        }
        else if(tmp->pire != NULL)
        {
            printf("P ");
        }
        else if(tmp->sinek != NULL)
        {
            printf("S ");
        }
        else
        {
            printf("X ");
        }
        index ++;
        tmp = tmp->next;
    }
}

struct Node* ekle(struct Node* head,struct Node* new)
{
    if (head == NULL) 
    {
        head = new;
    }
    else
    {
        struct Node* last = head;
        while(last->next != NULL)
        {
            last = last->next;
        }
        last->next = new;
    }
    return head;
}

struct Node* deleteNode(struct Node* head)
{
    if (head == NULL)
    {
        return head;
    }

    struct Node* prev = NULL;
    struct Node* sil = head;

    while(sil->next != NULL)
    {
        prev = sil;
        sil = sil->next;
    }

    if(sil == head)
    {
        yokEt(sil);
        return NULL;
    }
    
    prev->next = NULL;
    yokEt(sil);
    return head;
}