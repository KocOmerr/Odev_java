#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <Canli.h>
#include <Bitki.h>
#include <Bocek.h>
#include <Sinek.h>
#include <Pire.h>
#include <Habitat.h>
#include <Node.h>
#include <windows.h>

int main()
{

    struct Node* head = NULL;

    // Dosya işlemleri için gerekli değişkenler
    FILE *dosya;
    char *dosyaAdi = "Veri.txt";
    dosya = fopen(dosyaAdi, "r");

    // Dosya açıldı mı kontrol et
    if (dosya == NULL) {
        printf("Dosya acilamadi.");
        return 1;
    }

    //sütun sayisi bul
    int satirdaki_sayi_sayisi = 0;
    char c;
    while ((c = getc(dosya)) != EOF) {
        if (c == ' ') {
            satirdaki_sayi_sayisi++;
        } else if (c == '\n') 
        {
            satirdaki_sayi_sayisi++;
            break;
        }        
    }
    fclose(dosya);  
    
    dosya = fopen("Veri.txt", "r");
    if (dosya == NULL) {
        printf("Dosya açma hatasi!");
        return 1;
    }


    int sayi = 0;
    struct Node* new = NULL;
    int konum = 0;
    while (fscanf(dosya, "%d", &sayi) != EOF) 
    {
        if(sayi >= 1 && sayi <= 9)
        {
            struct BITKI* bitki = bitkiOlustur(sayi);
            new = newNode(bitki, NULL, NULL, NULL, konum);
        }
        else if(sayi >= 10 && sayi <= 20)
        {
            struct BOCEK* bocek = bocekOlustur(sayi);
            new = newNode(NULL, bocek, NULL, NULL, konum);
        }
        else if(sayi >= 21 && sayi <= 50)
        {
            struct SINEK* sinek = sinekOlustur(sayi);
            new = newNode(NULL, NULL, sinek, NULL, konum);
        }
        else if(sayi >= 51 && sayi <= 99)
        {
            struct PIRE* pire= pireOlustur(sayi);
            new = newNode(NULL, NULL, NULL, pire, konum);
        }
        else
        {
            printf("Gecersiz veri araligi: %d\n", sayi);
        }
        konum ++;
        head = ekle(head, new);
    }

    fclose(dosya);

    struct HABITAT* habitat = habitatOlustur(satirdaki_sayi_sayisi);

    for(int i = 0 ; i < listLength(head) ; i ++ )
    {
        printf("Tur: %d\n",i+1);

        printList(head,satirdaki_sayi_sayisi);

        head = habitat->guncelle(habitat,head);
        printf("\n-------------------\n");
        Sleep(30);
        if(i != listLength(head) -1)
            system("cls");
    }

    habitat->yokEt(habitat);

    free(head);

    int uzunluk = listLength(head);

    for(int i = 0 ; i < uzunluk; i++)
    {
        head = deleteNode(head);
    }
        
    return 0;
}